# deepstream.io-clusternode-redis
A redis cluster bus implementation to allow deepstream nodes to scale
