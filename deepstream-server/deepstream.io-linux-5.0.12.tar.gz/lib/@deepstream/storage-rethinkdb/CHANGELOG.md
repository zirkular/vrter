## [2.0.0] 2019-08-07
  
### Feat

- Use typescript
- V4 API Compatible
- Include a read-only that logs a warning if data is set via the API

## [1.0.2] 2016-07-25

### Bug Fix

- Storage connector stores high level arrays under __dsList ( records should only contain objects and not arrays on a highlevel )

## [1.0.1] 2016-07-13

### Bug Fix

- Storage connector no longer mutates original object state

## [1.0.0] 2016-07-01
