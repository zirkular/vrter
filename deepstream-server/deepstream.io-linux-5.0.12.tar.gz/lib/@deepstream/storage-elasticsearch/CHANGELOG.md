## [1.0.1] 2016-07-25

### Bug Fix

###### Storage connector stores high level arrays under __dsList ( records should only contain objects and not arrays on a highlevel )

## [1.0.0] 2016-07-01
